import{l as a}from"./index-2ae232cf.js";const o=(o,e)=>a.request({url:`/huajian/upload/filesUpload/${e}`,method:"post",data:o});export{o as f};
