import{l as e}from"./index-2ae232cf.js";const t=()=>e.request({url:"/huajian/common/getCategoryList",method:"get"});export{t as g};
