import{l as a}from"./index-e9bc2ae8.js";const e=(e,o)=>a.request({url:`/huajian/upload/filesUpload/${o}`,method:"post",data:e});export{e as f};
