import{l as t}from"./index-413b608f.js";const e=()=>t.request({url:"/huajian/common/getCategoryList",method:"get"});export{e as g};
