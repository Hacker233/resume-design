import{l as e}from"./index-e9bc2ae8.js";const t=()=>e.request({url:"/huajian/common/getCategoryList",method:"get"});export{t as g};
