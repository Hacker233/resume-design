import{l as a}from"./index-413b608f.js";const o=(o,s)=>a.request({url:`/huajian/upload/filesUpload/${s}`,method:"post",data:o});export{o as f};
