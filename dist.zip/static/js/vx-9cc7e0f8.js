const a="/static/images/vx-49efd78a.jpg";export{a as _};
